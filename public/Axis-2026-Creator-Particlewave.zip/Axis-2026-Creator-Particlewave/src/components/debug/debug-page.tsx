import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { AppHeader } from "@/components/app-header.tsx";
import { Button } from "@/components/ui/button.tsx";
import { useProblems } from "@/lib/pda/use-problems.ts";
import type { Problem, ProblemFix } from "@/lib/pda/validate.ts";
import { usePdaStore } from "@/store/pda-store.ts";

const FILTERS = [
  { id: "all", label: "All" },
  { id: "error", label: "Errors" },
  { id: "warning", label: "Warnings" },
  { id: "delete", label: "Suggested delete" },
  { id: "fix", label: "Suggested fix" },
] as const;

export function DebugPage() {
  const applyBulk = usePdaStore((s) => s.applyBulk);
  const jumpTo = usePdaStore((s) => s.jumpTo);
  const navigate = useNavigate();
  const { issues, stats, busy } = useProblems();
  const [filter, setFilter] = useState<(typeof FILTERS)[number]["id"]>("all");
  const [query, setQuery] = useState("");
  const [picked, setPicked] = useState<Record<string, boolean>>({});

  const visible = issues.filter((issue) => {
    if (filter === "error" && issue.level !== "error") return false;
    if (filter === "warning" && issue.level !== "warning") return false;
    if (filter === "delete" && issue.recommend !== "delete") return false;
    if (filter === "fix" && issue.recommend !== "fix") return false;
    if (query) {
      const hay = `${issue.message} ${issue.path} ${issue.code} ${issue.value ?? ""}`.toLowerCase();
      if (!hay.includes(query.trim().toLowerCase())) return false;
    }
    return true;
  });

  const selectedIds = visible.filter((issue) => issue.id && picked[issue.key]).map((issue) => issue.id!) ;
  const uniqueSelected = [...new Set(selectedIds)];

  const apply = (issue: Problem, fix: ProblemFix) => {
    if (!issue.id) return;
    if (fix.type === "delete") applyBulk([], [issue.id]);
    else applyBulk([{ id: issue.id, patch: fixToPatch(fix) }]);
    setPicked((p) => {
      const next = { ...p };
      delete next[issue.key];
      return next;
    });
  };

  const acceptIssues = (list: Problem[]) => {
    const patches: { id: string; patch: Record<string, unknown> }[] = [];
    for (const issue of list) {
      if (!issue.id) continue;
      const fix = preferredFix(issue);
      if (!fix) continue;
      patches.push({ id: issue.id, patch: fixToPatch(fix) });
    }
    if (!patches.length) return;
    applyBulk(patches);
    setPicked({});
  };

  const selectable = visible.filter((issue) => issue.id);
  const suggestedFixes = visible.filter((issue) => issue.recommend === "fix" && issue.id && preferredFix(issue));
  const selectedFixable = selectable.filter((issue) => picked[issue.key] && preferredFix(issue));
  const recommendedDeletes = visible.filter((i) => i.recommend === "delete" && i.id).map((i) => i.id!);

  const open = (issue: Problem) => {
    if (!issue.id) return;
    jumpTo(issue.id);
    void navigate({ to: "/" });
  };

  return (
    <div className="flex min-h-dvh flex-col bg-bg text-fg">
      <AppHeader />
      <main className="canvas-wash mx-auto flex w-full max-w-5xl flex-1 flex-col px-4 py-6">
        <div className="mb-5">
          <h1 className="text-2xl font-medium tracking-tight">Debug</h1>
          <p className="mt-1 max-w-2xl text-sm text-muted">
            Catch empty rows, unknown names, missing pictures, and HUD wrap. Apply a suggested correction or delete the
            entry. Jump opens it in the editor.
            {busy ? " Rechecking in the background…" : ""}
          </p>
        </div>

        <div className="mb-4 grid gap-2 sm:grid-cols-4">
          <Stat label="Issues" value={String(stats.total)} />
          <Stat label="Errors" value={String(stats.errors)} tone={stats.errors ? "danger" : undefined} />
          <Stat label="Warnings" value={String(stats.warnings)} tone={stats.warnings ? "warn" : undefined} />
          <Stat label="Suggested deletes" value={String(stats.deletable)} />
        </div>

        <div className="mb-3 flex flex-wrap items-center gap-2">
          {FILTERS.map((item) => (
            <button
              key={item.id}
              onClick={() => setFilter(item.id)}
              className={`h-8 rounded-sm px-3 text-xs ${
                filter === item.id ? "bg-elevated text-fg" : "text-muted hover:text-fg"
              }`}
            >
              {item.label}
            </button>
          ))}
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Filter message or path…"
            className="h-8 min-w-40 flex-1 rounded-sm border border-border bg-surface px-2 text-sm outline-none placeholder:text-subtle focus:border-accent"
          />
        </div>

        <div className="mb-3 flex flex-wrap gap-2">
          <Button
            size="sm"
            variant="secondary"
            disabled={!selectable.length}
            onClick={() => {
              const next: Record<string, boolean> = {};
              for (const issue of selectable) next[issue.key] = true;
              setPicked(next);
            }}
          >
            Select all
          </Button>
          <Button size="sm" variant="ghost" disabled={!Object.values(picked).some(Boolean)} onClick={() => setPicked({})}>
            Deselect all
          </Button>
          <Button size="sm" disabled={!selectedFixable.length} onClick={() => acceptIssues(selectedFixable)}>
            Accept selected ({selectedFixable.length})
          </Button>
          <Button
            size="sm"
            disabled={!suggestedFixes.length}
            onClick={() => acceptIssues(suggestedFixes)}
          >
            Accept all suggested ({suggestedFixes.length})
          </Button>
          <Button
            size="sm"
            variant="danger"
            disabled={!uniqueSelected.length}
            onClick={() => {
              applyBulk([], uniqueSelected);
              setPicked({});
            }}
          >
            Delete selected ({uniqueSelected.length})
          </Button>
          <Button
            size="sm"
            variant="secondary"
            disabled={!recommendedDeletes.length}
            onClick={() => {
              applyBulk([], [...new Set(recommendedDeletes)]);
              setPicked({});
            }}
          >
            Delete all suggested ({[...new Set(recommendedDeletes)].length})
          </Button>
        </div>

        {!visible.length ? (
          <p className="rounded-md border border-border bg-surface px-4 py-8 text-center text-sm text-ok">
            {issues.length ? "Nothing matches this filter." : "No issues. Structure looks exportable."}
          </p>
        ) : (
          <ul className="space-y-2">
            {visible.slice(0, 400).map((issue) => (
              <li key={issue.key} className="rounded-md border border-border bg-surface p-3">
                <div className="flex items-start gap-3">
                  {issue.id ? (
                    <input
                      type="checkbox"
                      className="mt-1"
                      checked={Boolean(picked[issue.key])}
                      onChange={(e) => setPicked((p) => ({ ...p, [issue.key]: e.target.checked }))}
                    />
                  ) : (
                    <span className="mt-1 size-4" />
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span
                        className={`text-xs uppercase tracking-[0.14em] ${
                          issue.level === "error" ? "text-danger" : "text-warn"
                        }`}
                      >
                        {issue.level === "error" ? "Error" : "Watch"}
                      </span>
                      <span className="text-xs text-subtle">{issue.kind}</span>
                      {issue.recommend === "delete" ? (
                        <span className="text-xs text-danger">suggest delete</span>
                      ) : issue.recommend === "fix" ? (
                        <span className="text-xs text-ok">suggest fix</span>
                      ) : null}
                    </div>
                    <p className="mt-1 text-sm">{issue.message}</p>
                    <p className="mt-0.5 text-xs text-subtle">{issue.path}</p>
                    {issue.suggestions.length ? (
                      <p className="mt-1 text-xs text-muted">Close matches: {issue.suggestions.join(" · ")}</p>
                    ) : null}
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {issue.fixes.map((fix) => (
                        <button
                          key={fix.label}
                          className={`h-7 rounded-sm px-2 text-xs ${
                            fix.type === "delete"
                              ? "border border-danger/40 text-danger hover:bg-danger/10"
                              : "bg-elevated text-fg hover:bg-surface"
                          }`}
                          onClick={() => apply(issue, fix)}
                        >
                          {fix.label}
                        </button>
                      ))}
                      {issue.id ? (
                        <button className="h-7 rounded-sm px-2 text-xs text-muted hover:text-fg" onClick={() => open(issue)}>
                          Jump
                        </button>
                      ) : null}
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
        {visible.length > 400 ? (
          <p className="mt-3 text-xs text-subtle">Showing 400 of {visible.length}. Narrow the filter to see the rest.</p>
        ) : null}
      </main>
    </div>
  );
}

function preferredFix(issue: Problem): ProblemFix | null {
  return issue.fixes.find((fix) => fix.type !== "delete") ?? null;
}

function fixToPatch(fix: ProblemFix): Record<string, unknown> {
  if (fix.type === "clear") return { [fix.field]: "" };
  if (fix.type === "set") return { [fix.field]: fix.value };
  if (fix.type === "rewards") return { rewards: fix.rewards };
  return {};
}

function Stat({ label, value, tone }: { label: string; value: string; tone?: "danger" | "warn" }) {
  return (
    <div className="rounded-md border border-border bg-surface px-3 py-2">
      <p className="text-xs uppercase tracking-[0.14em] text-muted">{label}</p>
      <p className={`mt-1 text-lg tabular-nums ${tone === "danger" ? "text-danger" : tone === "warn" ? "text-warn" : ""}`}>
        {value}
      </p>
    </div>
  );
}
